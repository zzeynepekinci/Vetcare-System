CREATE TABLE Doctor(
    doctorID serial NOT NULL primary key,
	fname varchar(30) NOT NULL,
	lname varchar(30) NOT NULL
);

CREATE TABLE Customer(
	customerID serial primary key,
	fname varchar(30) NOT NULL,
	lname varchar(30) NOT NULL,
	email varchar(50) NOT NULL,
	passwords varchar(16)
);


CREATE SEQUENCE animal_seq
START WITH 1  -- İlk değer
INCREMENT BY 1  -- Artış miktarı
NO CYCLE;  -- Maksimum değere ulaştığında sıfırlanmasın


CREATE TABLE Animal (
    animalID INTEGER PRIMARY KEY DEFAULT NEXTVAL('animal_seq'),  
    species VARCHAR(30) NOT NULL,
    a_name VARCHAR(30) NOT NULL,
    age INTEGER CHECK (age > 0),  -- Yaşın 0'dan küçük olamayacağını belirten kısıt
    customer_id INTEGER NOT NULL,
	CONSTRAINT fk_customer FOREIGN KEY (customer_id) REFERENCES Customer(customerID) ON DELETE CASCADE
);

CREATE TABLE HealthInfo(
	animalID INTEGER NOT NULL PRIMARY KEY,
    CONSTRAINT fk_animal FOREIGN KEY (animalID) REFERENCES Animal(animalID) ON DELETE CASCADE,
    healthStatus VARCHAR(255) CHECK (healthStatus IN ('Healthy', 'Sick', 'In Treatment')),  -- Sağlık durumu için sayı kısıtı
    vaccinationDate DATE,       
    treatment VARCHAR(255)      
);

CREATE TABLE Appointment(
	appointmentID serial NOT NULL primary key,
	customerID INTEGER  NOT NULL,
	doctorID INTEGER  NOT NULL,
	animalID INTEGER NOT NULL,
	appointmentDate DATE NOT NULL CHECK (appointmentDate >= CURRENT_DATE), 
	appointmentTime TIME NOT NULL,
	appointmentType varchar(255),
	CONSTRAINT fk_customer FOREIGN KEY (customerID) REFERENCES Customer(customerID) ON DELETE CASCADE,
	CONSTRAINT fk_animal FOREIGN KEY (animalID) REFERENCES Animal(animalID) ON DELETE CASCADE,
	CONSTRAINT fk_doctor FOREIGN KEY (doctorID) REFERENCES Doctor(doctorID) ON DELETE CASCADE
);




INSERT INTO Doctor (fname, lname) VALUES
('John', 'Doe'),
('Jane', 'Smith'),
('Michael', 'Johnson'),
('Emily', 'Davis'),
('David', 'Miller'),
('Sarah', 'Wilson'),
('James', 'Taylor'),
('Linda', 'Anderson'),
('Robert', 'Thomas'),
('Maria', 'Martinez');


INSERT INTO Customer (fname, lname, email, passwords) VALUES
('Alice', 'Johnson', 'alice.johnson@example.com', 'password1'),
('Bob', 'Brown', 'bob.brown@example.com', 'password2'),
('Charlie', 'Williams', 'charlie.williams@example.com', 'password3'),
('Diana', 'Jones', 'diana.jones@example.com', 'password4'),
('Eva', 'Miller', 'eva.miller@example.com', 'password5'),
('Frank', 'Davis', 'frank.davis@example.com', 'password6'),
('Grace', 'Martinez', 'grace.martinez@example.com', 'password7'),
('Hannah', 'Garcia', 'hannah.garcia@example.com', 'password8'),
('Ivy', 'Rodriguez', 'ivy.rodriguez@example.com', 'password9'),
('Jack', 'Wilson', 'jack.wilson@example.com', 'password10');


INSERT INTO Animal (species, a_name, age,customer_id) VALUES
('Dog', 'Buddy', 3,1),
('Cat', 'Whiskers', 2,2),
('Bird', 'Chirpy', 1,3),
('Dog', 'Max', 5,3),
('Rabbit', 'Fluffy', 2,4),
('Hamster', 'Squeaky', 1,5),
('Fish', 'Bubbles', 1,6),
('Dog', 'Rex', 4,7),
('Cat', 'Luna', 3,8),
('Bird', 'Sky', 2,9);


INSERT INTO HealthInfo (animalID, healthStatus, vaccinationDate, treatment) VALUES
(1, 'Healthy', '2024-01-10', 'None'),
(2, 'Sick', '2023-12-15', 'Antibiotic Treatment'),
(3, 'Healthy', '2024-02-20', 'None'),
(4, 'Healthy', '2023-11-30', 'None'),
(5, 'Healthy', '2024-03-10', 'None'),
(6, 'Sick', '2023-12-05', 'Vitamin Supplements'),
(7, 'Healthy', '2024-04-01', 'None'),
(8, 'Healthy', '2024-05-20', 'None'),
(9, 'Healthy', '2023-11-10', 'None'),
(10, 'Healthy', '2024-06-15', 'None');



INSERT INTO Appointment (customerID, doctorID,animalID, appointmentDate, appointmentTime, appointmentType) VALUES
(1, 1,1, '2025-01-15', '10:00', 'Check-up'),
(2, 2,2, '2025-02-20', '11:30', 'Emergency'),
(3, 3,3, '2025-03-10', '14:00', 'Vaccination'),
(4, 4,3, '2025-04-05', '09:30', 'Surgery'),
(5, 5, 4,'2025-05-12', '16:00', 'Routine Check'),
(6, 6, 5,'2025-06-18', '13:30', 'Check-up'),
(7, 7,6, '2025-07-25', '12:00', 'Emergency'),
(8, 8,7, '2025-08-14', '15:00', 'Vaccination'),
(9, 9,8, '2025-09-20', '09:00', 'Routine Check'),
(10, 10,9, '2025-10-30', '17:00', 'Surgery');




CREATE OR REPLACE FUNCTION check_appointment_availability()
RETURNS TRIGGER AS $$
BEGIN
    
    IF EXISTS (
        SELECT 1
        FROM Appointment
        WHERE doctorID = NEW.doctorID
          AND appointmentDate = NEW.appointmentDate
          AND appointmentTime = NEW.appointmentTime
    ) THEN
        
        RAISE EXCEPTION 'Randevu çakışması: Doktor bu saatte başka bir randevuya sahip.' 
        USING ERRCODE = 'P0001';
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger tanımı
CREATE TRIGGER check_appointment_before_insert
BEFORE INSERT ON Appointment
FOR EACH ROW
EXECUTE FUNCTION check_appointment_availability();


-- Trigger fonksiyonu
CREATE OR REPLACE FUNCTION prevent_same_name_update()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.a_name = OLD.a_name THEN
	    
        RAISE EXCEPTION  'Hayvanın ismi değişmemiş! Güncelleme işlemi iptal edildi.'
        USING ERRCODE = 'P0002';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

--trigger tanımı
CREATE TRIGGER check_name_change
BEFORE UPDATE ON Animal
FOR EACH ROW
EXECUTE FUNCTION prevent_same_name_update();



CREATE VIEW appointment_details AS
SELECT 
    a.animalID, 
    a.a_name AS animal_name, 
    ap.appointmentID, 
    ap.appointmentDate, 
    ap.appointmentType
FROM 
    Animal a
JOIN 
    Appointment ap ON a.animalID = ap.animalID;


CREATE OR REPLACE FUNCTION get_health_info()
RETURNS SETOF HealthInfo AS
$$
DECLARE
    health_cursor CURSOR FOR SELECT * FROM HealthInfo;
    health_record HealthInfo%ROWTYPE;
BEGIN
    FOR health_record IN health_cursor LOOP
        RETURN NEXT health_record;
    END LOOP;
    RETURN;
END;
$$ LANGUAGE plpgsql;


CREATE TYPE vaccination_appointment  AS (appointmentID INTEGER, appointmentDate DATE , appointmentType varchar(255));  



CREATE OR REPLACE FUNCTION get_vaccination_appointments2(animal_id INT)
RETURNS SETOF vaccination_appointment AS $$ 
DECLARE  
    appointment vaccination_appointment;
BEGIN  
    FOR appointment IN
        SELECT a.appointmentID, a.appointmentDate, a.appointmentType 
        FROM Appointment a
        WHERE a.animalID = animal_id
        EXCEPT
        SELECT a.appointmentID, a.appointmentDate, a.appointmentType
        FROM Appointment a
        WHERE a.appointmentType != 'Vaccination'
    LOOP
        RETURN NEXT appointment;
    END LOOP;
    RETURN;  
END;  
$$ LANGUAGE 'plpgsql';

CREATE OR REPLACE FUNCTION get_animal_appointments(animal_id INT)
RETURNS TABLE (
    appointmentID INT,
    appointmentDate DATE,
    appointmentType VARCHAR
) AS $$
BEGIN
    RETURN QUERY
    SELECT a.appointmentID, a.appointmentDate, a.appointmentType
    FROM appointment_details AS a
    WHERE a.animalID = animal_id;
END;
$$ LANGUAGE plpgsql;