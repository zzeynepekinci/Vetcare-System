package vetcare;

public class Animal {
	private int animalID;
	private String species;
	private String a_name;
	private int age;
	public Animal(int animalID, String species, String a_name, int age) {
		super();
		this.animalID = animalID;
		this.species = species;
		this.a_name = a_name;
		this.age = age;
	}
	public int getAnimalID() {
		return animalID;
	}
	public void setAnimalID(int animalID) {
		this.animalID = animalID;
	}
	public String getSpecies() {
		return species;
	}
	public void setSpecies(String species) {
		this.species = species;
	}
	public String getA_name() {
		return a_name;
	}
	public void setA_name(String a_name) {
		this.a_name = a_name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
}
