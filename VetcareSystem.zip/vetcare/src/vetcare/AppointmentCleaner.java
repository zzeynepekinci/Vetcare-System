package vetcare;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Timer;
import java.util.TimerTask;

public class AppointmentCleaner {

    public static void main(String[] args) {
        Timer timer = new Timer(true);

        
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                cleanPastAppointments();
            }
        }, 0, 3600000); 

        System.out.println("Appointment cleaner is running. Press Ctrl+C to stop.");
        
        
        try {
            Thread.sleep(Long.MAX_VALUE);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    static void cleanPastAppointments() {
        String query = """
            DELETE FROM Appointment 
            WHERE (appointmentDate < CURRENT_DATE)
               OR (appointmentDate = CURRENT_DATE AND appointmentTime < CURRENT_TIME)
            """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            int affectedRows = statement.executeUpdate();
            System.out.println("Deleted " + affectedRows + " past appointment(s).\n");

        } catch (SQLException e) {
            System.err.println("Error while cleaning past appointments: " + e.getMessage());
        }
    }
}
