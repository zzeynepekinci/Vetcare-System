package vetcare;

import java.sql.Date;
import java.sql.Time;

public class Appointment {
    private int appointmentID;
    private int customerID;
    private int doctorID;
    private Date appointmentDate;
    private Time appointmentTime;
    private String appointmentType;
    private int hayvanID;
	public Appointment(int appointmentID, int customerID, int doctorID, Date appointmentDate, Time appointmentTime,
			String appointmentType, int hayvanID) {
		super();
		this.appointmentID = appointmentID;
		this.customerID = customerID;
		this.doctorID = doctorID;
		this.appointmentDate = appointmentDate;
		this.appointmentTime = appointmentTime;
		this.appointmentType = appointmentType;
		this.hayvanID = hayvanID;
	}
	
	public int getAppointmentID() {
		return appointmentID;
	}
	public void setAppointmentID(int appointmentID) {
		this.appointmentID = appointmentID;
	}
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public int getDoctorID() {
		return doctorID;
	}
	public void setDoctorID(int doctorID) {
		this.doctorID = doctorID;
	}
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	public void setAppointmentDate(Date appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public Time getAppointmentTime() {
		return appointmentTime;
	}
	public void setAppointmentTime(Time appointmentTime) {
		this.appointmentTime = appointmentTime;
	}
	public String getAppointmentType() {
		return appointmentType;
	}
	public void setAppointmentType(String appointmentType) {
		this.appointmentType = appointmentType;
	}
    
    
    
}
