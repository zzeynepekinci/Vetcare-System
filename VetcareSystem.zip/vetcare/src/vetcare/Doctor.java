package vetcare;

public class Doctor {
    private int doctorID;
    private String fname;
    private String lname;
	public int getDoctorID() {
		return doctorID;
	}
	public void setDoctorID(int doctorID) {
		this.doctorID = doctorID;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public Doctor(int doctorID, String fname, String lname) {
		super();
		this.doctorID = doctorID;
		this.fname = fname;
		this.lname = lname;
	}
    
}
