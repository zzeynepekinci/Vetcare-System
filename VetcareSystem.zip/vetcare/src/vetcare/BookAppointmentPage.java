package vetcare;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BookAppointmentPage extends JFrame {
    private JComboBox<String> animalDropdown;
    private JComboBox<String> doctorDropdown;
    private JComboBox<String> timeSlotDropdown;
    private JComboBox<String> appointmentTypeDropdown;
    private JTextField dateField;

    private int customerId;

    public BookAppointmentPage(int customerId) {
    	setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Zeynep\\OneDrive - Yildiz Technical University\\Masaüstü\\vetcare\\ikon.png"));
        this.customerId = customerId;
        setTitle("Book an appointment");
        setSize(588, 498);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        initComponents();
    }

    private void initComponents() {
        JPanel panel = new JPanel();
        panel.setLayout(null); 

        
        JLabel animalLabel = new JLabel("Choose Pet:");
        animalLabel.setForeground(SystemColor.textHighlight);
        animalLabel.setFont(new Font("Imprint MT Shadow", Font.PLAIN, 15));
        animalDropdown = new JComboBox<>(getAnimalsByCustomer().toArray(new String[0]));
        
        
        JLabel doctorLabel = new JLabel("Choose Doctor:");
        doctorLabel.setForeground(SystemColor.textHighlight);
        doctorLabel.setFont(new Font("Imprint MT Shadow", Font.PLAIN, 15));
        doctorDropdown = new JComboBox<>(getAllDoctors().toArray(new String[0]));
        
        
        JLabel dateLabel = new JLabel("Date (YYYY-MM-DD):");
        dateLabel.setForeground(SystemColor.textHighlight);
        dateLabel.setFont(new Font("Imprint MT Shadow", Font.PLAIN, 15));
        dateField = new JTextField();
        
        
        JLabel timeSlotLabel = new JLabel("Time:");
        timeSlotLabel.setForeground(SystemColor.textHighlight);
        timeSlotLabel.setFont(new Font("Imprint MT Shadow", Font.PLAIN, 15));
        timeSlotDropdown = new JComboBox<>(updateTimeSlots().toArray(new String[0]));
        
        
        JLabel appointmentTypeLabel = new JLabel("Appointment Type:");
        appointmentTypeLabel.setForeground(SystemColor.textHighlight);
        appointmentTypeLabel.setFont(new Font("Imprint MT Shadow", Font.PLAIN, 15));
        String[] appointmentTypes = {"Check-up", "Vaccination", "Surgery"};
        appointmentTypeDropdown = new JComboBox<>(appointmentTypes);
        appointmentTypeDropdown.setModel(new DefaultComboBoxModel(new String[] {"Check-up", "Vaccination", "Surgery"}));
        
        
        JButton bookButton = new JButton("Book an Appointment");
        bookButton.setForeground(SystemColor.textHighlight);
        bookButton.setFont(new Font("Imprint MT Shadow", Font.PLAIN, 15));
        bookButton.addActionListener(this::bookAppointment);

       
        animalLabel.setBounds(20, 110, 100, 30);
        animalDropdown.setBounds(233, 110, 200, 30);
        
        doctorLabel.setBounds(20, 163, 120, 30);
        doctorDropdown.setBounds(233, 163, 200, 30);
        
        dateLabel.setBounds(20, 218, 165, 30);
        dateField.setBounds(233, 219, 200, 30);
        
        timeSlotLabel.setBounds(20, 273, 100, 30);
        timeSlotDropdown.setBounds(233, 273, 200, 30);
        
        appointmentTypeLabel.setBounds(20, 326, 165, 30);
        appointmentTypeDropdown.setBounds(233, 326, 200, 30);
        
        bookButton.setBounds(233, 385, 200, 40);

        
        panel.add(animalLabel);
        panel.add(animalDropdown);
        panel.add(doctorLabel);
        panel.add(doctorDropdown);
        panel.add(dateLabel);
        panel.add(dateField);
        panel.add(timeSlotLabel);
        panel.add(timeSlotDropdown);
        panel.add(appointmentTypeLabel);
        panel.add(appointmentTypeDropdown);
        panel.add(bookButton);

        
        getContentPane().add(panel, BorderLayout.CENTER);
    }

    private List<String> getAnimalsByCustomer() {
        List<String> animals = new ArrayList<>();
        String query = "SELECT animalID, a_name FROM Animal WHERE customer_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, customerId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                animals.add(rs.getInt("animalID") + " - " + rs.getString("a_name"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "An error occurred while loading pet information: " + e.getMessage());
        }
        return animals;
    }

    private List<String> getAllDoctors() {
        List<String> doctors = new ArrayList<>();
        String query = "SELECT doctorID, fname, lname FROM Doctor";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                doctors.add(rs.getInt("doctorID") + " - " + rs.getString("fname") + " " + rs.getString("lname"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "An error occurred while loading doctor information: " + e.getMessage());
        }
        return doctors;
    }

    private List<String> updateTimeSlots() {
        List<String> allSlots = new ArrayList<>();
        for (int hour = 9; hour <= 16; hour++) {
            allSlots.add(String.format("%02d:00", hour));
        }
        return allSlots;
    }

    private void bookAppointment(ActionEvent e) {
        String animalSelection = (String) animalDropdown.getSelectedItem();
        String doctorSelection = (String) doctorDropdown.getSelectedItem();
        String timeSlotSelection = (String) timeSlotDropdown.getSelectedItem();
        String appointmentType = (String) appointmentTypeDropdown.getSelectedItem();
        String date = dateField.getText();

        if (animalSelection != null && doctorSelection != null && timeSlotSelection != null && appointmentType != null && !date.isEmpty()) {
            int animalId = Integer.parseInt(animalSelection.split(" - ")[0]);
            int doctorId = Integer.parseInt(doctorSelection.split(" - ")[0]);

            
            try {
                java.sql.Date sqlDate = java.sql.Date.valueOf(date);
                
                if (sqlDate.before(java.sql.Date.valueOf(java.time.LocalDate.now()))) {
                    JOptionPane.showMessageDialog(this, "Error: The selected date is in the past. Please select a valid date.", "Invalid Date", JOptionPane.ERROR_MESSAGE);
                    return;  
                }
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(this, "Error: Invalid date format. Please enter the date in the format YYYY-MM-DD.", "Invalid Date", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String insertQuery = "INSERT INTO Appointment (customerID, animalID, doctorID, appointmentDate, appointmentTime, appointmentType) " +
                    "VALUES (?, ?, ?, ?, ?, ?)";
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement insertStmt = conn.prepareStatement(insertQuery)) {
                insertStmt.setInt(1, customerId);
                insertStmt.setInt(2, animalId);
                insertStmt.setInt(3, doctorId);
                insertStmt.setDate(4, java.sql.Date.valueOf(date));
                insertStmt.setTime(5, java.sql.Time.valueOf(timeSlotSelection + ":00"));
                insertStmt.setString(6, appointmentType);
                insertStmt.executeUpdate();

                JOptionPane.showMessageDialog(this, "Appointment created successfully!");
                dispose();
            } catch (SQLException ex) {
                if ("P0001".equals(ex.getSQLState())) {
                    JOptionPane.showMessageDialog(this, "Doctor has another appointment in this time zone.");
                } else {
                    JOptionPane.showMessageDialog(this, "An unexpected error occurred while saving the appointment.");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.");
        }
    }

}




