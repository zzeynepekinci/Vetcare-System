package vetcare;

import java.sql.Date;

public class HealthInfo {
    private int animalID;
    private String healthstatus;
    private Date vaccinationDate;
    private String treatment;
	public HealthInfo(int animalID, String healthstatus, Date vaccinationDate, String treatment) {
		super();
		this.animalID = animalID;
		this.healthstatus = healthstatus;
		this.vaccinationDate = vaccinationDate;
		this.treatment = treatment;
	}
	public int getAnimalID() {
		return animalID;
	}
	public void setAnimalID(int animalID) {
		this.animalID = animalID;
	}
	public String getHealthstatus() {
		return healthstatus;
	}
	public void setHealthstatus(String healthstatus) {
		this.healthstatus = healthstatus;
	}
	public Date getVaccinationDate() {
		return vaccinationDate;
	}
	public void setVaccinationDate(Date vaccinationDate) {
		this.vaccinationDate = vaccinationDate;
	}
	public String getTreatment() {
		return treatment;
	}
	public void setTreatment(String treatment) {
		this.treatment = treatment;
	}
	
}
