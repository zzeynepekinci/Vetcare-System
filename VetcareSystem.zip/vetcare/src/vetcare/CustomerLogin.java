package vetcare;

import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import java.awt.Font;
import java.awt.SystemColor;

public class CustomerLogin extends JFrame {

    private JTextField emailField;
    private JPasswordField passwordField;
    private JLabel background;

    public CustomerLogin() {
        setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Zeynep\\OneDrive - Yildiz Technical University\\Masaüstü\\vetcare\\ikon.png"));
        setTitle("Customer Login");
        setSize(1000, 1000);  
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);  
        initComponents();
    }

    private void initComponents() {
        
        JPanel panel = new JPanel(null); 

        
        JLabel emailLabel = new JLabel("E-mail:");
        emailLabel.setForeground(SystemColor.textHighlight);
        emailLabel.setFont(new Font("Imprint MT Shadow", Font.PLAIN, 15));
        emailLabel.setBounds(111, 216, 150, 30); 
        emailField = new JTextField();
        emailField.setBackground(SystemColor.window);
        emailField.setBounds(222, 218, 200, 30);

        
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setForeground(SystemColor.textHighlight);
        passwordLabel.setFont(new Font("Imprint MT Shadow", Font.PLAIN, 15));
        passwordLabel.setBounds(111, 277, 150, 30); 
        passwordField = new JPasswordField();
        passwordField.setBounds(222, 279, 200, 30);

        
        JButton loginButton = new JButton("Login");
        loginButton.setBackground(SystemColor.window);
        loginButton.setFont(new Font("Imprint MT Shadow", Font.PLAIN, 15));
        loginButton.setForeground(SystemColor.textHighlight);
        loginButton.setBounds(322, 339, 100, 30);
        loginButton.addActionListener(new LoginAction());

        
        panel.add(emailLabel);
        panel.add(emailField);
        panel.add(passwordLabel);
        panel.add(passwordField);
        panel.add(loginButton);

        
        ImageIcon originalImage = new ImageIcon("C:\\Users\\Zeynep\\OneDrive - Yildiz Technical University\\Masaüstü\\vetcare\\backgroundlogin.jpg");
        
        Image scaledImage = originalImage.getImage().getScaledInstance(getWidth(), getHeight(), Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        
        background = new JLabel(scaledIcon);
        background.setBackground(SystemColor.textHighlight);
        background.setBounds(0, 10, getWidth(), getHeight()); 
        panel.add(background); 

        
        getContentPane().add(panel, BorderLayout.CENTER);

       
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                background.setBounds(0, 0, getWidth(), getHeight());
            }
        });
    }
    
    

    private Customer authenticateCustomer(String email, String password) {
        String sql = "SELECT customerID, fname, lname, email, passwords FROM Customer WHERE email = ? AND passwords = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, email);
            pstmt.setString(2, password);

            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                int customerID = rs.getInt("customerID");
                String firstName = rs.getString("fname");
                String lastName = rs.getString("lname");
                String dbEmail = rs.getString("email");
                String dbPassword = rs.getString("passwords");

                
                Customer customer = new Customer(firstName, lastName, dbEmail, dbPassword,customerID);
                customer.setCustomerID(customerID);
                customer.setEmail(dbEmail);
                customer.setPassword(dbPassword);
                customer.setFname(firstName);
                customer.setLname(lastName);

                return customer;
               
            } else {
                return null; //kulanıcı bulunamadı
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }
    private class LoginAction implements ActionListener {
    	@Override
        public void actionPerformed(ActionEvent e) {
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());

            Customer customer = authenticateCustomer(email, password);
            if (customer != null) {
                JOptionPane.showMessageDialog(CustomerLogin.this, "Login successful!");

                
                new CustomerMainpage(customer).setVisible(true);

                
                CustomerLogin.this.dispose();
            } else {
                JOptionPane.showMessageDialog(CustomerLogin.this, "Invalid email or password.", "Login Failed", JOptionPane.ERROR_MESSAGE);
            }
        }
    }



    public static void main(String[] args) {
        
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                CustomerLogin loginFrame = new CustomerLogin();
                loginFrame.setVisible(true);  
            }
        });
    }
}




