package vetcare;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.SystemColor;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Toolkit;

class ViewAppointmentsPage extends JFrame {
    private int customerID;

    public ViewAppointmentsPage(int customerID) {
    	setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Zeynep\\OneDrive - Yildiz Technical University\\Masaüstü\\vetcare\\ikon.png"));
        this.customerID = customerID;

        setTitle("View Appointments");
        setSize(600, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        
        getContentPane().setLayout(null);

        
        setBackgroundImage();

        initComponents();
    }

    private void setBackgroundImage() {
        
        ImageIcon backgroundImage = new ImageIcon("C:\\Users\\Zeynep\\OneDrive - Yildiz Technical University\\Masaüstü\\vetcare\\b.jpeg");
        Image img = backgroundImage.getImage();
        Image newImg = img.getScaledInstance(getWidth(), getHeight(), Image.SCALE_SMOOTH);
        backgroundImage = new ImageIcon(newImg);

        
        JLabel backgroundLabel = new JLabel(backgroundImage);
        backgroundLabel.setBounds(0, 0, getWidth(), getHeight());

        
        setContentPane(backgroundLabel);
    }

    private void initComponents() {
        ArrayList<Integer> animalIDs = fetchAnimalIds();
        ArrayList<String> animalNames = fetchAnimalNames();

        if (animalIDs.isEmpty() || animalNames.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No pet records found!", "Warning", JOptionPane.INFORMATION_MESSAGE);
            dispose();
            return;
        }

        String[] animalOptions = new String[animalIDs.size()];
        for (int i = 0; i < animalIDs.size(); i++) {
            animalOptions[i] = animalIDs.get(i) + " - " + animalNames.get(i); // Example: "123 - Bella"
        }

        
        JComboBox<String> animalComboBox = new JComboBox<>(animalOptions);
        animalComboBox.setPreferredSize(new Dimension(300, 30)); // Set combo box size
        animalComboBox.setBounds(150, 100, 300, 30); // Set position and size

        
        JButton viewButton = new JButton("View Appointments");
        viewButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				
			}
        });
        viewButton.setForeground(SystemColor.textHighlight);
        viewButton.setFont(new Font("Imprint MT Shadow", Font.PLAIN, 15));
        viewButton.setPreferredSize(new Dimension(317, 51));
        viewButton.setBounds(150, 150, 317, 51); 

        viewButton.addActionListener(e -> {
            String selectedAnimal = (String) animalComboBox.getSelectedItem();
            if (selectedAnimal != null) {
                int selectedAnimalID = Integer.parseInt(selectedAnimal.split(" - ")[0]); 
                displayAppointments(selectedAnimalID);
            }
        });

        
        JButton viewVaccinationButton = new JButton("View Vaccination Schedule");
        viewVaccinationButton.setForeground(SystemColor.textHighlight);
        viewVaccinationButton.setFont(new Font("Imprint MT Shadow", Font.PLAIN, 15));
        viewVaccinationButton.setPreferredSize(new Dimension(318, 51));
        viewVaccinationButton.setBounds(150, 220, 318, 51); 
        viewVaccinationButton.addActionListener(e -> {
            String selectedAnimal = (String) animalComboBox.getSelectedItem();
            if (selectedAnimal != null) {
                int selectedAnimalID = Integer.parseInt(selectedAnimal.split(" - ")[0]);
                displayVaccinationSchedule(selectedAnimalID);
            }
        });

        
        JLabel label = new JLabel("Choose a pet");
        label.setForeground(SystemColor.textHighlight);
        label.setFont(new Font("Imprint MT Shadow", Font.PLAIN, 16));
        label.setBounds(230, 60, 150, 30); 

        
        getContentPane().add(label);
        getContentPane().add(animalComboBox);
        getContentPane().add(viewButton);
        getContentPane().add(viewVaccinationButton);
    }

    private ArrayList<Integer> fetchAnimalIds() {
        ArrayList<Integer> animalIDs = new ArrayList<>();
        String sql = "SELECT animalID FROM Animal WHERE customer_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, customerID);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                animalIDs.add(rs.getInt("animalID"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        return animalIDs;
    }

    private ArrayList<String> fetchAnimalNames() {
        ArrayList<String> animalNames = new ArrayList<>();
        ArrayList<Integer> animalIDs = fetchAnimalIds();
        String sql = "SELECT a_name FROM Animal WHERE animalID = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            for (Integer animalID : animalIDs) {
                pstmt.setInt(1, animalID);
                ResultSet rs = pstmt.executeQuery();

                if (rs.next()) {
                    animalNames.add(rs.getString("a_name"));
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        return animalNames;
    }

    private void displayAppointments(int animalID) {
        String sql = "SELECT * FROM get_animal_appointments(?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, animalID);
            ResultSet rs = pstmt.executeQuery();

            ArrayList<Object[]> appointmentsData = new ArrayList<>();

            while (rs.next()) {
                int appointmentID = rs.getInt("appointmentID");
                String date = rs.getString("appointmentDate");
                String description = rs.getString("appointmentType");

                
                appointmentsData.add(new Object[]{appointmentID, date, description});
            }

            if (appointmentsData.size() > 0) {
                
                String[] columnNames = {"Appointment ID", "Date", "Description"};
                Object[][] data = appointmentsData.toArray(new Object[0][]);

                JTable appointmentsTable = new JTable(data, columnNames);
                JScrollPane scrollPane = new JScrollPane(appointmentsTable); 

                
                JFrame appointmentFrame = new JFrame("Appointments");
                appointmentFrame.setSize(600, 400);
                appointmentFrame.setLocationRelativeTo(null);

                
                JButton deleteButton = new JButton("Delete Appointment");
                deleteButton.addActionListener(e -> {
                    int selectedRow = appointmentsTable.getSelectedRow();
                    if (selectedRow != -1) {
                        int appointmentID = (int) appointmentsTable.getValueAt(selectedRow, 0); 
                        deleteAppointment(appointmentID);
                        appointmentFrame.dispose(); 
                    } else {
                        JOptionPane.showMessageDialog(appointmentFrame, "Please select an appointment to delete.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                });

                
                JPanel panel = new JPanel(new BorderLayout());
                panel.add(scrollPane, BorderLayout.CENTER);
                panel.add(deleteButton, BorderLayout.SOUTH);

                appointmentFrame.getContentPane().add(panel);
                appointmentFrame.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "No appointments found for selected animal!", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }



    private void displayVaccinationSchedule(int animalID) {
        String sql = "SELECT * FROM get_vaccination_appointments2(?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, animalID); 
            ResultSet rs = pstmt.executeQuery();

            StringBuilder vaccinationSchedule = new StringBuilder();

            while (rs.next()) {
                int appointmentID = rs.getInt("appointmentID");
                Date date = rs.getDate("appointmentDate"); 
                String type = rs.getString("appointmentType");

                vaccinationSchedule.append("ID: ").append(appointmentID)
                .append(", Date: ").append(date.toString())  // toString() ile doğru formatta yazdırılır
                .append(", Type: ").append(type)
                .append("\n");
            }

            if (vaccinationSchedule.length() > 0) {
                JOptionPane.showMessageDialog(this, vaccinationSchedule.toString(), "Vaccination Schedule", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "No vaccination appointment found for selected pet!", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteAppointment(int appointmentID) {
        String sql = "DELETE FROM Appointment WHERE appointmentID = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, appointmentID);
            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(this, "Appointment deleted successfully!", "Information", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Appointment could not be deleted!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}





