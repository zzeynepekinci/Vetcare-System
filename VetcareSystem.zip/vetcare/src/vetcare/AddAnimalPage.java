package vetcare;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AddAnimalPage extends JFrame {
    private JTextField speciesField;
    private JTextField nameField;
    private JTextField ageField;
    private int customerID;

    public AddAnimalPage(int customerID) {
        setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Zeynep\\OneDrive - Yildiz Technical University\\Masaüstü\\vetcare\\ikon.png"));
        this.customerID = customerID;

        setTitle("Add Pet");
        setSize(579, 468);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        
        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setLayout(null);
        setContentPane(layeredPane);

        
        ImageIcon backgroundIcon = new ImageIcon("C:\\Users\\Zeynep\\OneDrive - Yildiz Technical University\\Masaüstü\\vetcare\\b.jpeg");
        JLabel backgroundLabel = new JLabel(new ImageIcon(backgroundIcon.getImage().getScaledInstance(579, 468, Image.SCALE_SMOOTH)));
        backgroundLabel.setBounds(0, 0, 579, 468);
        layeredPane.add(backgroundLabel, Integer.valueOf(0));

        initComponents(layeredPane);
    }

    private void initComponents(JLayeredPane layeredPane) {
        
        JLabel speciesLabel = new JLabel("Species:");
        speciesLabel.setForeground(new Color(0, 0, 139));
        speciesLabel.setFont(new Font("Imprint MT Shadow", Font.BOLD, 15));
        speciesLabel.setBackground(Color.WHITE);
        speciesLabel.setOpaque(true); 

        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setForeground(new Color(0, 0, 128));
        nameLabel.setFont(new Font("Imprint MT Shadow", Font.BOLD, 15));
        nameLabel.setBackground(Color.WHITE);
        nameLabel.setOpaque(true); 

        JLabel ageLabel = new JLabel("Age:");
        ageLabel.setForeground(new Color(0, 0, 128));
        ageLabel.setFont(new Font("Imprint MT Shadow", Font.BOLD, 15));
        ageLabel.setBackground(Color.WHITE);
        ageLabel.setOpaque(true); 

        speciesField = new JTextField();
        nameField = new JTextField();
        ageField = new JTextField();

        JButton addButton = new JButton("Add");
        addButton.setForeground(new Color(0, 0, 128));
        addButton.setFont(new Font("Imprint MT Shadow", Font.BOLD, 15));

        
        speciesLabel.setBounds(50, 90, 100, 30);
        speciesField.setBounds(315, 92, 200, 30);

        nameLabel.setBounds(50, 142, 100, 30);
        nameField.setBounds(315, 143, 200, 30);

        ageLabel.setBounds(50, 193, 100, 30);
        ageField.setBounds(315, 194, 200, 30);

        addButton.setBounds(191, 286, 131, 43);

        
        addButton.addActionListener(new AddAnimalAction());

        
        layeredPane.add(speciesLabel, Integer.valueOf(1));
        layeredPane.add(speciesField, Integer.valueOf(1));
        layeredPane.add(nameLabel, Integer.valueOf(1));
        layeredPane.add(nameField, Integer.valueOf(1));
        layeredPane.add(ageLabel, Integer.valueOf(1));
        layeredPane.add(ageField, Integer.valueOf(1));
        layeredPane.add(addButton, Integer.valueOf(1));
    }

    private class AddAnimalAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String species = speciesField.getText();
            String name = nameField.getText();
            int age;

            try {
                age = Integer.parseInt(ageField.getText());
                if (age < 0) throw new NumberFormatException();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(AddAnimalPage.this, "Please Enter a Valid Age!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            
            try (Connection conn = DatabaseConnection.getConnection()) {
                String sql = "INSERT INTO Animal (species, a_name, age, customer_id) VALUES (?, ?, ?, ?)";
                PreparedStatement pstmt = conn.prepareStatement(sql);

                pstmt.setString(1, species);
                pstmt.setString(2, name);
                pstmt.setInt(3, age);
                pstmt.setInt(4, customerID);

                int rowsInserted = pstmt.executeUpdate();

                if (rowsInserted > 0) {
                    JOptionPane.showMessageDialog(AddAnimalPage.this, "Pet Added Successfully!");
                    dispose();
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(AddAnimalPage.this, "An Unexpected Error Occured: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}



