package vetcare;

import javax.swing.*;
import java.awt.*;

public class CustomerMainpage extends JFrame {
    private static Customer customer;

    public CustomerMainpage(Customer customer) {
    	setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Zeynep\\OneDrive - Yildiz Technical University\\Masaüstü\\vetcare\\ikon.png"));
        this.customer = customer; 

        setTitle("Welcome, " + customer.getFname());
        setSize(1000, 1000);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        
        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setPreferredSize(new Dimension(1000, 1000));

        
        ImageIcon originalImage = new ImageIcon("C:\\Users\\Zeynep\\OneDrive - Yildiz Technical University\\Masaüstü\\vetcare\\b.jpeg");
        Image scaledImage = originalImage.getImage().getScaledInstance(1000, 1000, Image.SCALE_SMOOTH);
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        JLabel background = new JLabel(scaledIcon);
        background.setBounds(0, 0, 1000, 1000); 
        layeredPane.add(background, Integer.valueOf(0)); 

        
        JLabel welcomeLabel = new JLabel("Welcome, " + customer.getFname() + " " + customer.getLname());
        welcomeLabel.setForeground(new Color(0, 0, 139));
        welcomeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        welcomeLabel.setBounds(301, 104, 400, 50); 
        layeredPane.add(welcomeLabel, Integer.valueOf(1));

        JButton addAnimalButton = new JButton("Add Pet");
        addAnimalButton.setForeground(SystemColor.textHighlight);
        addAnimalButton.setFont(new Font("Imprint MT Shadow", Font.PLAIN, 15));
        addAnimalButton.setBounds(100, 300, 316, 65);
        layeredPane.add(addAnimalButton, Integer.valueOf(1));

        JButton viewAnimalsButton = new JButton("View My Pets");
        viewAnimalsButton.setForeground(SystemColor.textHighlight);
        viewAnimalsButton.setFont(new Font("Imprint MT Shadow", Font.PLAIN, 15));
        viewAnimalsButton.setBounds(100, 400, 316, 65);
        layeredPane.add(viewAnimalsButton, Integer.valueOf(1));

        JButton viewAppointmentsButton = new JButton("View Pet Appointments");
        viewAppointmentsButton.setForeground(SystemColor.textHighlight);
        viewAppointmentsButton.setFont(new Font("Imprint MT Shadow", Font.PLAIN, 15));
        viewAppointmentsButton.setBounds(600, 300, 300, 65);
        layeredPane.add(viewAppointmentsButton, Integer.valueOf(1));

        JButton bookAppointmentButton = new JButton("Book an Appointment");
        bookAppointmentButton.setForeground(SystemColor.textHighlight);
        bookAppointmentButton.setFont(new Font("Imprint MT Shadow", Font.PLAIN, 15));
        bookAppointmentButton.setBounds(600, 400, 300, 65);
        layeredPane.add(bookAppointmentButton, Integer.valueOf(1));

        
        addAnimalButton.addActionListener(e -> new AddAnimalPage(customer.getCustomerID()).setVisible(true));
        viewAnimalsButton.addActionListener(e -> new DisplayAnimalPage(customer.getCustomerID()).setVisible(true));
        viewAppointmentsButton.addActionListener(e -> new ViewAppointmentsPage(customer.getCustomerID()).setVisible(true));
        bookAppointmentButton.addActionListener(e -> new BookAppointmentPage(customer.getCustomerID()).setVisible(true));

        
        getContentPane().add(layeredPane);

        
        addComponentListener(new java.awt.event.ComponentAdapter() {
            @Override
            public void componentResized(java.awt.event.ComponentEvent e) {
                background.setBounds(0, 0, getWidth(), getHeight());
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new CustomerMainpage(customer).setVisible(true);
        });
    }
}



