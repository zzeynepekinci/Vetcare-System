package vetcare;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

class DisplayAnimalPage extends JFrame {
    private int customerID;

    public DisplayAnimalPage(int customerID) {
        setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Zeynep\\OneDrive - Yildiz Technical University\\Masaüstü\\vetcare\\ikon.png"));
        this.customerID = customerID;

        setTitle("My Pets");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        int animalCount = fetchAnimalCount();
        JOptionPane.showMessageDialog(this, "Your total number of registered pets: " + animalCount, "Info", JOptionPane.INFORMATION_MESSAGE);

        
        String[] columnNames = {"ID", "Name", "Species", "Health Status"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);

        
        String sql = "SELECT a.animalID, a.a_name, a.species, h.healthStatus FROM Animal a " +
                     "LEFT JOIN HealthInfo h ON a.animalID = h.animalID WHERE a.customer_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, customerID);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                int animalID = rs.getInt("animalID");
                String name = rs.getString("a_name");
                String species = rs.getString("species");
                String healthStatus = rs.getString("healthStatus");

                healthStatus = (healthStatus != null) ? healthStatus : "No Info";

                Object[] row = {animalID, name, species, healthStatus};
                tableModel.addRow(row);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        
        JTable animalTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(animalTable);

        JButton updateButton = new JButton("Update Pet Info");
        updateButton.addActionListener(e -> updateAnimal());

        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(updateButton);

        
        BackgroundPanel backgroundPanel = new BackgroundPanel();
        backgroundPanel.setLayout(new BorderLayout());
        backgroundPanel.add(scrollPane, BorderLayout.CENTER);
        backgroundPanel.add(buttonPanel, BorderLayout.SOUTH);

        getContentPane().add(backgroundPanel);
    }

    private int fetchAnimalCount() {
        String sql = "SELECT customer_id, COUNT(*) AS hayvan_sayisi FROM Animal GROUP BY customer_id HAVING customer_id = ?";
        int animalCount = 0;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, customerID);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                animalCount = rs.getInt("hayvan_sayisi");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        return animalCount;
    }

    private void updateAnimal() {
        JTextField animalIDField = new JTextField();
        JTextField nameField = new JTextField();
        JTextField ageField = new JTextField();

        JPanel inputPanel = new JPanel(new GridLayout(3, 2));
        inputPanel.add(new JLabel("Pet ID: "));
        inputPanel.add(animalIDField);
        inputPanel.add(new JLabel("New Name: "));
        inputPanel.add(nameField);
        inputPanel.add(new JLabel("New Age: "));
        inputPanel.add(ageField);

        int result = JOptionPane.showConfirmDialog(this, inputPanel, "Update Pet", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            String animalID = animalIDField.getText().trim();
            String newName = nameField.getText().trim();
            String newAge = ageField.getText().trim();

            if (animalID.isEmpty() || newName.isEmpty() || newAge.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields!", "Warning", JOptionPane.WARNING_MESSAGE);
                return;
            }

            String updateSql = "UPDATE Animal SET a_name = ?, age = ? WHERE animalID = ? AND customer_id = ?";
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(updateSql)) {

                pstmt.setString(1, newName);
                pstmt.setInt(2, Integer.parseInt(newAge));
                pstmt.setInt(3, Integer.parseInt(animalID));
                pstmt.setInt(4, customerID);

                int rowsUpdated = pstmt.executeUpdate();

                if (rowsUpdated > 0) {
                    JOptionPane.showMessageDialog(this, "Pet updated successfully!", "Successfull", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, "The pet was not found or does not belong to you!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException ex) {
               
                if (ex.getMessage().toLowerCase().contains("hayvanın ismi değişmemiş! güncelleme işlemi iptal edildi.")) {
                    JOptionPane.showMessageDialog(this, "The pet's name is already the same! Please enter a different name.", "Warning", JOptionPane.WARNING_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, "A database error occurred. Try again later.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Age and ID fields must be numeric!", "Warning", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    
    class BackgroundPanel extends JPanel {
        private Image backgroundImage;

        public BackgroundPanel() {
            backgroundImage = new ImageIcon("C:\\\\Users\\\\Zeynep\\\\OneDrive - Yildiz Technical University\\\\Masaüstü\\\\vetcare\\\\b.jpeg").getImage(); // Update the image path
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }
    }
}




