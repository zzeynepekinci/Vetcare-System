/**
 * 
 */
/**
 * 
 */
module vetcare {
	requires java.desktop;
	requires java.sql;
}